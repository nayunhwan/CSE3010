insert into PRINTER values (3001, 'true', 'ink-jet', 1999);
insert into PRINTER values (3002, 'true', 'ink-jet', 2499);
insert into PRINTER values (3003, 'false', 'laser', 3599);
insert into PRINTER values (3004, 'false', 'laser', 3499);
insert into PRINTER values (3005, 'false', 'ink-jet', 2599);
insert into PRINTER values (3006, 'true', 'dry', 1999);