drop table Product;
dropt table PC;
drop table Laptop;
drop table Printer;