insert into Laptop values (2001, 100, 20, 1.10, 9.5, 1999);
insert into Laptop values (2002, 117, 12, 0.75, 11.3, 2499);
insert into Laptop values (2003, 117, 32, 1.00, 10.4, 3599);
insert into Laptop values (2004, 133, 16, 1.10, 11.2, 3499);
insert into Laptop values (2005, 133, 16, 1.00, 11.3, 2599);
insert into Laptop values (2006, 120, 8, 0.81, 12.1, 1999);
insert into Laptop values (2007, 150, 16, 1.35, 12.1, 4799);
insert into Laptop values (2008, 120, 16, 1.10, 12.1, 2099);