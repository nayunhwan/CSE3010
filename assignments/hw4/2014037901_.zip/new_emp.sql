prompt CREATE NEW EMPLOYEE RECORD;
prompt ;
prompt Enter the employee\'s information: ;


accept my_last_name char format a10 prompt 'Last Name: ';
accept my_emp_no number format '9999' prompt 'Employee #: ';
accept my_salary number format '99999.99' default '1000.00' prompt 'Salary [1000]: ';
accept my_comm number format '9999.99' default '0' prompt 'Commision % [0]: ';
accept my_hire_date date format 'mm/dd/yyyy' prompt 'Hire Data [mm/dd/yyyy]: ';
prompt 'List of avarilable jobs: ';
select distinct (job) from emp;
accept my_job char format a10 prompt 'Job: ';
prompt 'List of department numbers and names: ';
select deptno, dname from dept order by deptno asc;
accept my_deptno number format '9999' prompt 'Department #: ';

insert into emp values (&my_emp_no, '&my_last_name', '&my_job', to_date('&my_hire_date', 'mm/dd/yyyy'), &my_salary, &my_comm, &my_deptno);
