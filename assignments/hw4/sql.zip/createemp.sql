create table emp
(
	empno	number(6),
	ename	varchar2(10),
	job	varchar2(10),
	hiredate	date,
	sal	number(10),
	comm	number(6),
	deptno	number(6)
);