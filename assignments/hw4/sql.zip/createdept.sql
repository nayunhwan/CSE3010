create table dept
(
	deptno	number(6),
	dname	varchar2(10),
	loc	varchar2(10)
);