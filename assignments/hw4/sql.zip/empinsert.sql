insert into emp values (7369,'SMITH','CLERK','80/12/17',800,NULL,20);
insert into emp values (7499,'ALLEN','SALESMAN','81/02/02',1600,300,30);
insert into emp values (7586,'WADD','SALESMAN','91/02/23',1250,500,30);
insert into emp values (7866,'ALIS','MANAGER','83/02/22',2000,NULL,10);